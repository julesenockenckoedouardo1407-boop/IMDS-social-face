# IMDS Social v1.0

Prototype mobile de l'Institution Mixte Le Domaine du Savoir (IMDS).

## Modules prévus
Accueil, publications, annonces, événements, membres, documents, profils, notifications, messagerie, administration et évolutions futures.

## Version 1.0
Cette première base est légère et fonctionne comme une application web installable (PWA). Elle est conçue pour être ensuite empaquetée en application Android et reliée à une base de données en ligne.
